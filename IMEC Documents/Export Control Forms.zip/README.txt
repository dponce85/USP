Both imec and TSMC need to comply to government export regulations which is why the included export control forms must be completed by you and send back.
Please note that complete, consistent and unambiguous information in the export forms is a must to be able to perform the (dry-run) tape-out.
In case of any doubt, please consult with your legal department.

•	imec Export Form (to be completed & signed);
•	TSMC Export Form (to be completed & signed).

In both documents, your project name and TM number (= mask set reference) should be explicitly mentioned.