#!/bin/sh 
#-----------------------------------------------------------------------------
# Taiwan Semiconductor Manufacturing Company, Ltd.
#-----------------------------------------------------------------------------
#
# CADENCE LEF 5.5 Stream Layer Mapping Table Generator 
#
#-----------------------------------------------------------------------------
# History:
#
# REV 1.0 21/07/03   created
# REV 2.0 14/05/08   for 018 process, only for 6lm
#
#-----------------------------------------------------------------------------

#
# mapping table
#
M3='#-----------------------------------------------------------------------------
# Taiwan Semiconductor Manufacturing Company, Ltd.
#-----------------------------------------------------------------------------
#
# CADENCE LEF 5.5 Stream layer mapping table for TSMC DSD 
#
#-----------------------------------------------------------------------------
# Layer/ Object Name Layer/ Object Type Layer Number Datatype
# <t_ layerObjectName> <t_ objectType> <n_ layerNum> <n_ datatype>
POLY1           NET                             13      0
CONT            VIA                             15      0
METAL1		NET, SPNET, VIA			16	0
METAL2		NET, SPNET, VIA			18	0
METAL3		NET, SPNET, VIA			28	0
VIA12		VIA				17	0
VIA23		VIA				27	0
METAL1		PIN				40	0
METAL2		PIN				41	0
METAL3		PIN				42	0
METAL1		FILL				16	1
METAL2		FILL				18	1
METAL3		FILL				28	1
VIA12		VIAFILL				17	1
VIA23		VIAFILL				27	1
DIEAREA 	ALL 				62	0
COMP		ALL				59	0
NAME		COMP				59	0
NAME		METAL1/PIN			40	0
NAME		METAL2/PIN			41	0
NAME		METAL3/PIN			42	0'
M4='METAL4		NET, SPNET, VIA			31	0
METAL4		FILL				31	1
METAL4		PIN				43	0
VIA34		VIAFILL				29	1
VIA34		VIA				29	0
NAME		METAL4/PIN			43	0'
M5='METAL5		NET, SPNET, VIA			33	0
METAL5		FILL				33	1
METAL5		PIN				44	0
VIA45		VIAFILL				32	1
VIA45		VIA				32	0
NAME		METAL5/PIN			44	0'
M6='METAL6		NET, SPNET, VIA			38	0
METAL6		FILL				38	1
METAL6		PIN				45	0
VIA56		VIAFILL				39	1
VIA56		VIA				39	0
NAME		METAL6/PIN			45	0'


EXE=`basename $0`
HELP="
 
CADENCE LEF5.5 Stream Layer Mapping Table Utility:
 
> $EXE <options>

Example:

> $EXE -layer 4 

Options:
 
  -h|-help        HELP, print this message
 
  -layer          Metal Layer number 6|5|4. 
                  Create a \"gds2.map\" for the specified layer number.

"
#
# argument
#
mapfile="gds2.map"
layer="5"

[ -z "$1" ] && { echo "$HELP"; exit 0; }
while [ -n "$1" ]; do
case "$1" in
  -h|-help)
    echo "$HELP"; exit 0;
    ;;
  -layer)
    [ -z "$2" ] && { echo "Error: No arg $1 <layer number>"; exit 1; }
    layer="$2"; shift
    ;;
  -top)
    [ -z "$2" ] && { echo "Error: No arg $1 <layer thickness>"; exit 1; }
    top="$2"; shift
    ;;
  *)
    echo "$1" | grep '^-' >/dev/null && { echo "Unknown option $1"; exit 1; }
esac
shift
done

echo "$M3" > $mapfile

[ `expr $layer \> 3` = 1 ] && { echo "$M4" >> $mapfile ; }
[ `expr $layer \> 4` = 1 ] && { echo "$M5" >> $mapfile ; }
[ `expr $layer \> 5` = 1 ] && { echo "$M6" >> $mapfile ; }
[ `expr $layer \> 6` = 1 ] && { echo "$M7" >> $mapfile ; }

